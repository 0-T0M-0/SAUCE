package com.mycompany.mavenproject1;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class CalculatorModel {

    private final ScriptEngine engine;

    public CalculatorModel() {
        ScriptEngineManager manager = new ScriptEngineManager();
        this.engine = manager.getEngineByName("JavaScript");
    }

    /**
     * Evaluates a mathematical expression and returns the result.
     */
    public double evaluate(String expression) throws ScriptException {
        // Replace "!" with factorial logic
        expression = handleFactorial(expression);
        Object result = engine.eval(expression);
        return result instanceof Integer ? (Integer) result : (Double) result;
    }

    private String handleFactorial(String expression) {
        while (expression.contains("!")) {
            int index = expression.indexOf("!");
            int start = index - 1;

            // Find the start of the number
            while (start >= 0 && Character.isDigit(expression.charAt(start))) {
                start--;
            }
            start++;

            // Extract the number and calculate the factorial
            String numberStr = expression.substring(start, index);
            int number = Integer.parseInt(numberStr);
            int factorial = factorial(number);

            // Replace "number!" with the factorial result
            expression = expression.substring(0, start) + factorial + expression.substring(index + 1);
        }
        return expression;
    }

    private int factorial(int n) {
        if (n < 0) throw new IllegalArgumentException("Factorial not defined for negative numbers");
        int result = 1;
        for (int i = 2; i <= n; i++) {
            result *= i;
        }
        return result;
    }
}
