/*
 * main.cpp
 *
 *  Created on: Jan 15, 2019
 *      Author: jp
 */

#include "arbre.hpp"
#include <iostream>

using namespace std;

int main(){
	ABR *arbre = new ABR;

	*arbre = arbreVide();

    int n_elements = 15;
	int tab[n_elements] = {25,60,35,10,5,20,65,45,70,40,50,55,30,15,57};

    for (int i = 0; i < n_elements; i++)
        insere(tab[i],arbre);

    /*

	cout << recherche(30,*arbre) << endl;
	cout << recherche(35,*arbre) << endl;

	cout << taille(*arbre) << endl;

	cout << hauteur(*arbre) << endl;

	parcours_profondeur(*arbre,3);
    */

	return 0;
}
