/*
 * arbre.cpp
 *
 *  Created on: Jan 15, 2019
 *      Author: jp
 */

#include <algorithm>
#include <cstdlib>
#include <iostream>
#include "arbre.hpp"

using namespace std;

bool estVide(node* noeud){
    return (noeud == nullptr);
}

ABR arbreVide(){
    return nullptr;
}

void insere(int val,ABR* arbre){
    node* newNode = new node;
    newNode->valeur = val;
    newNode->filsdroit = nullptr;
    newNode->filsgauche = nullptr;

    if(estVide(*arbre))
        *arbre = newNode;
    else{
        node* tmp = *arbre;
        node* parent = nullptr;
        while(tmp != nullptr){
            parent = tmp;
            if(val < tmp->valeur)
                tmp = tmp->filsgauche;
            else
                tmp = tmp->filsdroit;
        }

        if(parent->valeur > val)
            parent->filsgauche = newNode;
        else
            parent->filsdroit = newNode;
    }
}

bool recherche(int val, ABR arbre){
    node* tmp = arbre;

    while(tmp != nullptr){
        if(val < tmp->valeur)
            tmp = tmp->filsgauche;
        else
            tmp = tmp->filsdroit;
    }

    if(estVide(tmp))
        return false;
    else
        return true;
}

int taille(ABR arbre){
    if(estVide(arbre))
        return 0;
    else
        return 1 + taille(arbre->filsdroit) + taille (arbre->filsgauche);
}

int hauteur(ABR arbre){
    if(estVide(arbre))
        return -1;
    else{
        int hauteurGauche = ;
        int hauteurDroite = ;

        return /* A compléter */
    }
}

void parcours_profondeur(ABR arbre, int version){
    if(!estVide(arbre)){
        if(version == 1){
            /* A compléter (parcours préfixe) */
        }
        else if(version == 2){
            /* A compléter (parcours suffixe) */
        }
        else{
            /* A compléter (parcours infixe) */
        }
    }
}

