/*
 * arbre.hpp
 *
 *  Created on: Jan 15, 2019
 *      Author: jp
 */

#ifndef ARBRE_HPP_
#define ARBRE_HPP_

typedef struct node node;

struct node{
	int valeur;
	node* filsgauche;
	node* filsdroit;
};

typedef node* ABR;

bool estVide(node* noeud);

ABR arbreVide();

void insere(int valeur, ABR* arbre);

bool recherche(int valeur, ABR arbre);

int taille(ABR arbre);

int hauteur(ABR arbre);

void parcours_profondeur(ABR arbre, int version);

#endif /* ARBRE_HPP_ */
